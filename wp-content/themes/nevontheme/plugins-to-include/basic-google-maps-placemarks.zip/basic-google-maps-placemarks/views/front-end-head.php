<!-- Begin Basic Google Map Placemarks head -->
<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
<!-- End Basic Google Map Placemarks head -->
