<p>When two markers overlap, the marker with the higher stacking order will be on top. The Default is 0.</p>

<p>
	<label for="<?php echo self::PREFIX; ?>zIndex">Stacking Order:</label>
	<input id="<?php echo self::PREFIX; ?>zIndex" name="<?php echo self::PREFIX; ?>zIndex" type="text" size="4" value="<?php echo $zIndex; ?>" />
</p>