=== DP Flickr Widget ===
Contributors: cloudstone
Donate link: http://dedepress.com/donate/
Tags: widget, widgets, flickr, photos, photo
Requires at least: 2.9
Tested up to: 3.1
Stable tag: 1.0

A widget which will display latest Flickr photos from specify user, user set, group or public. You also can set size, tags, number and sorting.

== Description ==

A widget which will display latest Flickr photos from specify user, user set, group or public. You also can set size, tags, number and sorting.

TODO: Better description and usage.

== Installation ==

1. Upload the entire folder `dp-flickr-widget` to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the widget 'DP Flickr' to your sidebar from Appearance->Widgets and configure the widget options.

== Frequently Asked Questions ==

No FAQ yet.

== Screenshots ==

No screentshots yet.

== Changelog ==

= Version 1.0 =

* Initial public release

== Upgrade Notice ==

No upgrade notice yet.
