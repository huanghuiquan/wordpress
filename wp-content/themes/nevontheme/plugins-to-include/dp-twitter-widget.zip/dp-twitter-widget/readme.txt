=== DP Twitter Widget ===
Contributors: cloudstone
Donate link: http://dedepress.com/donate/
Tags: widget, widgets, twitter, tweets
Requires at least: 2.9
Tested up to: 3.1
Stable tag: 1.0

A twitter widget for plugin with YQL support, for the people that twitter.com blocked for them. 

== Description ==

This twitter widget based popular `Wickett Twitter Widget` plugin. it adds YQL support, so you still can display your twitter updates in you wordpress site if twitter.com blocked for you. 

Notes: when you enable YQL support, `exclude replies` and `include Retweets` was deprecated.

TODO: Better description and usage.

== Installation ==

1. Upload the entire folder `dp-twitter-widget` to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the widget 'DP Twitter' to your sidebar from Appearance->Widgets and configure the widget options.

== Frequently Asked Questions ==

No FAQ yet.

== Screenshots ==

1. To use the widget, go to Appearance -> Widgets and Add "DP Twitter" widget, and configure it and click "Save".
2. This is what the widget looks like.

== Changelog ==

= Version 1.0 =

* Initial public release

== Upgrade Notice ==

No upgrade notice yet.
